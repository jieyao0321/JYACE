var bar=document.getElementById("banner"); 
var lit=bar.getElementsByTagName("ul");
var lits=lit[0].getElementsByTagName("li"); 
var n=1;
setInterval(function(){
	if(n>4) n=1
	lits.innerHTML="style=background-image: url(images/n.jpg)";
	n++;
},2000);